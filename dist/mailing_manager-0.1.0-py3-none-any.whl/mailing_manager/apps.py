from django.apps import AppConfig


class MailingManagerConfig(AppConfig):
    name = 'mailing_manager'
